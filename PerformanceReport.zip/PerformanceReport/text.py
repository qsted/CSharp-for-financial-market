import datetime as dt
import requests
import json
import re
from textwrap import dedent
import os
import pathlib

import dash
import dash_core_components as dcc
import dash_html_components as html

from utils import Header,get_menu 
#import dash_bootstrap_components as dbc

import dash_table
import pandas as pd

import sqlalchemy as db
from dash.dependencies import Input, Output, State

from sqlalchemy import select, update, delete
import dash_bootstrap_components as dbc

from app import app

#import dash_auth
# from flask_login import current_user
# from flask import session
from flask import request

#Local variables
var_username = ''

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath('../datasets').resolve()
print(DATA_PATH)

print(os.getcwd())
disk_engine = db.create_engine(
    "sqlite:///datasets/data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()

#=[{'SecurityLongName': 'SLF (F) Multi Asset Growth I', 'Username': 'shuo', 'custom_bench': '', 'isin': 'FR0010556910', 'stand_bench': '70% DJ Euro Stoxx50 Return (EUR) Index Level + 30% JPMorgan Government Bond Index Broad Hedged EUR TR '}, {'SecurityLongName': 'SLF (F) Multi Asset Balanced P', 'Username': 'shuo', 'custom_bench': '', 'isin': 'FR0000984361', 'stand_bench': '50% DJ Euro Stoxx50 Return (EUR) Index Level + 50% JPMorgan Government Bond Index Broad Hedged EUR TR '}, {'SecurityLongName': 'SL iFunds (CH) Bond Global Government+ (CHF hedged) I-A1', 'Username': 'shuo', 'custom_bench': '', 'isin': 'CH0023989624', 'stand_bench': 'BLOOMBERG GLOBAL AGG TREAS EX CHF TR HEDGED CHF '}, {'SecurityLongName': 'SLF (F) Money Market Euro I', 'Username': 'shuo', 'custom_bench': '', 'isin': 'FR0010089649', 'stand_bench': 'ESTR Capitalized 1 Day Index '}, {'SecurityLongName': 'SL iFunds (CH) Bond Global Corporates Short Term (CHF hedged) I-A1', 'Username': 'shuo', 'custom_bench': '', 'isin': 'CH0219870430', 'stand_bench': 'BLOOMBERG GLO AGG CORP 1-3 YR IND HEDGED CHF '}, {'SecurityLongName': 'SLF (F) Bond Global Inflation P', 'Username': 'shuo', 'custom_bench': '', 'isin': 'FR0010636399', 'stand_bench': 'BLOOMBERG GLOBAL INFLATION LINKED TR HEDGED EUR'}, {'SecurityLongName': 'AST SL Obligationen Global Staaten+ (CHF hedged) PM', 'Username': 'shuo', 'custom_bench': '', 'isin': 'CH0119561071', 'stand_bench': 'BLOOMBERG GLOBAL AGG TREAS EX CHF TR HEDGED CHF '}]

df = pd.read_sql_query(dedent("SELECT * from data_entries"),disk_engine, )