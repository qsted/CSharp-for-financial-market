import datetime as dt
import requests
import json
import re
from textwrap import dedent

import pathlib

import dash
import dash_core_components as dcc
import dash_html_components as html

from utils import Header,get_menu 
#import dash_bootstrap_components as dbc

import dash_table
import pandas as pd

import sqlalchemy as db
from dash.dependencies import Input, Output, State

from sqlalchemy import select, update, delete
import dash_bootstrap_components as dbc

from app import app

#import dash_auth
# from flask_login import current_user
# from flask import session
from flask import request

#Local variables
var_username = ''

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath('../datasets').resolve()
print(DATA_PATH)
#Fund list : a remplacer par appel am data desk
datafundList=pd.read_excel(DATA_PATH.joinpath('FundList.xlsx'))
datafundList['id'] = datafundList['ISIN']

#Liste custom bench, A remplacer par data base + form
df_cust_bench=pd.read_excel(DATA_PATH.joinpath('CustomBenchmark.xlsx'))
df_cust_bench['id'] = df_cust_bench['Benchmark']


# Data base model : SQL Engine
disk_engine = db.create_engine(
    "sqlite:///datasets/data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
metadata = db.MetaData()
SQL_table = db.Table(
    "data_entries",
    metadata,    
    db.Column("Username", db.String(255)),
    db.Column("SecurityLongName", db.String(255)),        
    db.Column("isin", db.String(255)),
    db.Column("FundClass", db.String(255)),
    db.Column("stand_bench", db.String(255)),
    db.Column("custom_bench", db.String(255)),
)

metadata.create_all(disk_engine)

df = pd.DataFrame(columns=("user_name","isin","custom_bench"))


"""
auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)
"""
#app.config.suppress_callback_exceptions = False

#app.layout = 

def layout(username):
    global var_username
    var_username = username
    
    return html.Div([
        Header(app,username),        
        html.Div([            
                configuration_tab()      
            ],
            className="sub_page")
        
        ],
        className="page",
    )   


def configuration_tab():
    
    dfSavedConf = pd.read_sql_query(dedent("SELECT * from data_entries where UserName = '{}' ".format(var_username)),disk_engine)
    #print(dfSavedConf)
    return html.Div([
                dbc.Row([
                     dbc.Col([                  
                            html.Div(html.H5('Fund selection  ',className='subtitle')),
                        ]),
                    ]),
                dbc.Row([
                   
                    dbc.Col([
                        html.Div( "Fund group : "),
                        html.Div([ 
                            dcc.Dropdown(
                                id="ddfundgroup",
                                options=[
                                    {"label": i, "value": i}
                                    for i in datafundList.PortfolioGroupType.unique()
                                ],
                                value="",
                                placeholder="Select a fund group.",
                                optionHeight   = 25,
                            )
                            
                            ]
                        ),
                        html.Div("Asset type :"),
                        html.Div([
                            dcc.Dropdown(
                                id="ddassettype",
                                value="",
                                placeholder="Select a fund group.",
                                multi=True,
                                optionHeight   = 25,
                                # style={
                                #         'height': '25px',
                                #         'width':'100%',
                                #         'display': 'inline-block',
                                #         'vertical-align': 'middle',
                                #     }
                                )
                            ]
                        ),
                        ],
                        width=3,
                        className="div_form"
                    ),
                    dbc.Col([                          
                        dash_table.DataTable(
                                id='ptflist',
                                columns=[
                                    {'id': 'SecurityLongName', 'name': 'SecurityLongName'},
                                    {'id': 'ISIN', 'name': 'ISIN'},
                                    {'id':'FundClass','name':'FundClass'},
                                    {'id': 'AssetClassName', 'name': 'AssetClassName'}
                                ],       
                                filter_action="native",
                                sort_action="native",
                                sort_mode="multi",
                                page_action='none',
                                row_selectable = 'multi',                                
                                style_cell={'textAlign': 'left',
                                    'minWidth': '100px', 
                                    'width': '100px', 
                                    'maxWidth': '100px',
                                    'overflow': 'hidden',
                                    'textOverflow': 'ellipsis'}, 
                                style_cell_conditional=[
                                        {
                                            'if': {'column_id': 'SecurityLongName'},
                                            'width': '100%',
                                        }],
                                css=[{'selector': '.dash-spreadsheet tr', 'rule': 'height: 10px;!important'},
                                     {'selector': '.dash-select-cell', 'rule': 'height: 10px;maxWidth:10px;'},
                                     {'selector': 'input', 'rule': 'margin-bottom: 3px;'},
                                     {'selector': '.cell-table', 'rule': 'margin-bottom: 0px;'},
                                     {'selector': '.dash-delete-cell', 'rule': 'height: 10px;'}, 
                                     {'selector': '.dash-spreadsheet-inner td', 'rule': 'height: 15px;'}, 
                                     {'selector': '.dash-spreadsheet-inner th', 'rule': 'height: 15px;'},                                      
                                     
                                     ],
                                fixed_rows={'headers': True},
                                style_table={'height': '200px', 
                                     'overflowY': 'auto',
                                     'border-bottom-width': '1px', 
                                     'border-bottom-style': 'solid',
                                     'border-bottom-color': 'rgb(211, 211, 211)',                                     
                                     },
                                
                        )],               
                        width = 9,
                    )  
                ]),
            #row2
            dbc.Row([
                        dbc.Col(                        
                            html.Div(id='isin_list',
                             style={'minHeigth': '50px', 
                                    'Heigth': '50px', 
                                    'maxHeigth': '50px',
                                       }),
                            width=9),
                        dbc.Col(
                            dbc.Button("Add to configuration",                                        
                                       id='submitfundlist',
                                       outline=True, 
                                       color="primary", 
                                       className="me-1",
                                       style ={'width':'100%'}), 
                            width = 3,
                        )
                    ],
                    justify="end",
                    ),
            html.Br(),
            #Row3
            dbc.Row([
                 dbc.Col([                        
                        html.Br(),
                        html.Div(html.H5('Configuration  ',className='subtitle')),
                    ]),
                ]),
            dbc.Row([
                    dbc.Col([
                        dash_table.DataTable(
                                id='ptfSetupList',
                                columns=[                                    
                                    {'id': 'SecurityLongName', 'name': 'Security Long Name'},
                                    {'id': 'isin', 'name': 'Isin'}, 
                                    {'id': 'FundClass', 'name': 'FundClass'},
                                    {'id': 'stand_bench', 'name': 'standard bench'},
                                    {'id': 'custom_bench', 'name': 'custom bench', 'presentation': 'dropdown'
                                             ,'editable':True}
                                ],        
                                style_cell={'textAlign': 'left',
                                            'minWidth': '100px', 
                                            'width': '100px', 
                                            'maxWidth': '100px',
                                            'textOverflow': 'ellipsis'},
                                style_cell_conditional=[
                                        {
                                            'if': {'column_id': 'SecurityLongName'},
                                            'width': '100%',
                                        }],  
                                dropdown={
                                    'custom_bench': {
                                        'options': [
                                                {"label": i, "value": i}
                                                for i in df_cust_bench.Benchmark.unique()
                                                
                                            ],
                                        }
                                    },                               
                                row_deletable=True,
                                sort_action="native",
                                page_action='none',
                                style_table={'maxHeight': '400px', },  
                                data = dfSavedConf.to_dict('records')
                        )
                        ])
                ]) ,
            # row4
            dbc.Row([
                        dbc.Col(
                                html.Div(id='divsavinglog')
                            ) ,
                        dbc.Col(
                                dbc.Button("Save",                                        
                                           id='submitconfig',
                                           outline=True, 
                                           color="primary", 
                                           className="me-1",
                                           style ={'width':'100%'}), 
                                width = 3
                            )                       
                    ],
                    justify="end",
                ),
        ])


#Refresh dropdown assettype on group selection
@app.callback(
    Output('ddassettype', 'options'),
    Input('ddfundgroup', 'value')
)
def refresh_dd_assettype(fund_group_value):
    df_filtered = datafundList[datafundList['PortfolioGroupType'].eq(fund_group_value)]
    lst = [{'label': i, 'value': i} for i in df_filtered.AssetClassName.fillna('N/A').unique()]
    return lst

#Refresh dropdown assettype : reset selected value on dd assettype
@app.callback(Output('ddassettype', 'value'),
              [Input('ddassettype', 'options')])
def ClearAssetType(value):
    return []

#refesh fund list on dd group or assettype selected + reset selected row
@app.callback(
    Output('ptflist', 'data'),    
    Output('ptflist', 'tooltip_data'), 
    Output('ptflist', 'selected_rows'),   
    Input('ddfundgroup', 'value'),    
    Input('ddassettype', 'value')
)
def refresh_ptflist(fund_group_value,asset_type_value):
    df_filtered = datafundList
    
    if (fund_group_value!=('') and fund_group_value != None) : 
        df_filtered = df_filtered[df_filtered.PortfolioGroupType.eq(fund_group_value)]
        
    if asset_type_value!=[] : 
        df_filtered = datafundList[datafundList.AssetClassName.isin(asset_type_value)]
    
    dt = df_filtered.to_dict('records')
    tooltip_data=[
        {
            column: {'value': str(value), 'type': 'markdown'}
            for column, value in row.items()
        } for row in dt
    ]
    return dt,tooltip_data,[]

#log selected fund
@app.callback(
    Output("isin_list","children"),
    Input("ptflist","selected_rows"),
    State('ptflist','data')
    )
def refreshLog(row_ids,data):
    if row_ids==[] or row_ids==None :
        return "No fund selected"
    return "Selected fund(s) : {}".format(str([data[i]['ISIN'] for i in row_ids]))


@app.callback(
    Output('ptfSetupList', 'data'),
    Output('ptfSetupList', 'tooltip_data'),
    Input('submitfundlist', 'n_clicks'),
    State('ptflist','selected_rows'),
    State('ptflist','data'),
    State('ptfSetupList', 'data'),
    State('ptfSetupList', 'columns')
)
def add_funds_to_config(n_clicks, selected_rows,ptfrows,confdata,confcol):
    if n_clicks is not None and selected_rows!=None :
        for i in selected_rows :    
            if ptfrows[i]['ISIN'] not in [rec['isin'] for rec in confdata] : 
                
                confdata += [{'Username':var_username,
                      'SecurityLongName':ptfrows[i]['SecurityLongName'] ,
                      'isin':ptfrows[i]['ISIN'] ,
                      'FundClass':ptfrows[i]['FundClass'],
                      'stand_bench':ptfrows[i]['BenchmarkOfficial_AMF'],
                      'custom_bench':''}]   
                #df = pd.json_normalize(confdata)
                #df.to_excel('benchtest.xlsx')
    
    if (confdata==None):
        return [],[]
    
    tooltip = [{column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in confdata]
    return confdata,tooltip




@app.callback(
    Output('divsavinglog', 'children'),
    Input('submitconfig', 'n_clicks'),
    State('ptfSetupList', 'data')
)
def save_config(n_clicks, confdata):
    if n_clicks is not None :   
        #vider la table pour le username selectionné
        #delete_user_cofig
        #insert des record de la table
        #insert_userconfig

        d = SQL_table.delete().where(SQL_table.c.Username == var_username)
        connection.execute(d)
        
        
        insert_entry = connection.execute(db.insert(SQL_table), confdata)
        #print(confdata)
        #print('username=',username)
        #print(request.authorization['username'])
        return 'Configuration saved'
    else :
        return ''
