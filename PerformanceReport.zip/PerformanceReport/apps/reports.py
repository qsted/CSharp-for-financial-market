
from datetime import date,datetime, timedelta
import time
import requests
import json
import re
from textwrap import dedent
import dash_bootstrap_components as dbc
import math


import pathlib

import dash
import dash_core_components as dcc
import dash_html_components as html

from utils import Header,get_menu 
#import dash_bootstrap_components as dbc

import dash_table
import pandas as pd

import sqlalchemy as db
from dash.dependencies import Input, Output, State
from sqlalchemy import select, update, delete
import plotly.graph_objs as go

from app import app


#import dash_auth
# from flask_login import current_user
# from flask import session
from flask import request
import plotly.express as px

#Local variables
#var_username = ''
df_final_global = pd.DataFrame(columns=['SecurityLongName'])
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath('../datasets').resolve()


# Data base model : SQL Engine
disk_engine = db.create_engine(
    "sqlite:///datasets/data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
metadata = db.MetaData()
SQL_table = db.Table(
    "data_entries",
    metadata,    
    db.Column("Username", db.String(255)),
    db.Column("SecurityLongName", db.String(255)),        
    db.Column("isin", db.String(255)),
    db.Column("FundClass", db.String(255)),
    db.Column("stand_bench", db.String(255)),
    db.Column("custom_bench", db.String(255)),
)

metadata.create_all(disk_engine)


def layout(username):
    global var_username
    var_username = username
    
    return html.Div([
        Header(app,username),        
        html.Div([            
                
                report_tab()      
            ],
            className="sub_page")
        
        ],
        className="page",
    )
    
def report_tab():
     dat = date.today() - timedelta(days=1)
    
     return html.Div([
                dbc.Row([
                        dbc.Col([
                                    html.A('Date d''analyse : '),
                                    dcc.DatePickerSingle(
                                         id='effetiveDate',
                                         max_date_allowed=dat,
                                         display_format='DD/MM/YYYY',
                                         date=dat,
                                         style = {
                                                 'height': '25px',
                                             }
                                     ),
                                    dbc.Button("Get data",                                        
                                        id='fetchData',
                                        n_clicks = 0,
                                        outline=True, 
                                        color="primary", 
                                        className="me-1"),

                                    ],
                                style = {'margin-right':'10px'},
                                className = 'div_form' 
                            )  
                            ]                 
                        ),
                dbc.Row(),
                dbc.Row(dbc.Col([
                    html.Div(id='divGridPlaceHolder')
                    ])
                ),
                dcc.Dropdown(
                            id="fundgroup",
                                # options=[
                                #     {"label": i, "value": i}
                                #     for i in df_final_global.SecurityLongName.unique()  
                                # ],
                                value="",
                                placeholder="Select a fund to show graph.",
                                optionHeight   = 25,
                            ),
                dbc.Button("show graph",                                        
                           id='showGraph',
                           n_clicks = 0,
                           outline=True, 
                           color="primary", 
                           className="me-1"),
                
                    html.Div(id='divGridPlaceHolder2')
                    
                
                
            ])
 
    
@app.callback(
    Output('fundgroup', 'options'),
    Input('effetiveDate', 'date'),
    prevent_initial_call=True
)
def refresh_fund(dt):
    data = getAmdatadeskData(dt)
    lst = [{'label': i, 'value': i} for i in data.SecurityLongName.unique()]
    
    return lst


@app.callback(
    Output('divGridPlaceHolder2', 'children'),
    Input('showGraph', 'n_clicks'),
    #State('effetiveDate', 'date'),
    Input('fundgroup', 'value'),
    prevent_initial_call=True
)
def showGraph(n_clicks,fund_select) :
    if (n_clicks is not None):
        
    
        #strDt = datetime.strptime(dt, '%Y-%m-%d').strftime('%d/%m/%y')
        
        #restData = getAmdatadeskData(dt)
        col_name=['YTD','13W','1W','1M','2Y','5Y']
        df_final_global=pd.read_excel('dffinal.xlsx')
        df=df_final_global[df_final_global['SecurityLongName']==fund_select]
        df=df.reset_index(drop=True)
        res = html.Div([
                    html.Div([
                            
                        #dbc.Row(html.H4('Perfomance fonds vs Benchmark : '+strDt,className='subtitle')),
                        dcc.Graph(
                            id="graph-1",
                         figure={"data":[
                              go.Bar(name='Fund', x=col_name, y=[df['fund_YTD'][0],
                                                                 df['fund_13W'][0],
                                                                 df['fund_1W'][0],
                                                                 df['fund_1M'][0],
                                                                 df['fund_2Y'][0],
                                                                 df['fund_5Y'][0]
                                                                 ]),
                              go.Bar(name='Bnech', x=col_name, y=[df['bench_YTD'][0],
                                                                 df['bench_13W'][0],
                                                                 df['bench_1W'][0],
                                                                 df['bench_1M'][0],
                                                                 df['bench_2Y'][0],
                                                                 df['bench_5Y'][0]])

                             ]}
                            ),
                        html.Br(),
                        html.Div(df_final_global['FundClass']),
                        
                    ])
            ])
        return res
    return ''

@app.callback(
    Output('divGridPlaceHolder', 'children'),
    Input('fetchData', 'n_clicks'),
    State('effetiveDate', 'date'),
    prevent_initial_call=True
)
def fetchData(n_clicks,dt) :
    if (n_clicks is not None):
        
        colDisplay = [
            'Fonds',
            'AUM me',
            '',
            'ytd',
            '3 months',
            '1 month',
            '1 week',
            '2 years',
            '5 years'
            ]
    
        strDt = datetime.strptime(dt, '%Y-%m-%d').strftime('%d/%m/%y')
        
        restData = getAmdatadeskData(dt)
        
        res = html.Div([
                    html.Div([
                            
                        dbc.Row(html.H4('Perfomance fonds vs Benchmark : '+strDt,className='subtitle')),
                        dbc.Row(
                            dbc.Col( make_dash_table(restData,colDisplay),
                                    width =8),                            
                            ),
                        html.Br(),
                        
                    ])
            ])
        return res
    return ''

def getAmdatadeskData(date):
    
    colDisplay = [
        'Fonds',
        'AUM me',
        '',
        'ytd',
        '3 months',
        '1 month',
        '1 week',
        '2 years',
        '5 years'
        ]
    
    df = pd.read_sql_query(dedent("SELECT * from data_entries where UserName = '{}' ".format(var_username)),disk_engine, )

    lstFundClass = ','.join(df["FundClass"])
    lstIsin = ','.join(df["isin"])
          
    
    urlRep02361_FundInfo = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02361?" \
        +"&FundClass='"+lstFundClass+"'&ReportDate='"+date+"'&Language='FR'&Domicile=''&AuMNNADashboardUnit=''&ShowTerminatedFunds=''&ReportingCurrency='EUR'" \
        +"&$select=ReportDate,ISIN,FundClass,FundDefinition,FundDefinitionName,SecurityLongName,FundClassCcy,LegalForm,AssetClass,AssetClassName,AMBFundCategory,AMBClassificationInternal,AMBFundType,MgmFees,BenchmarkOfficial_AMF,BenchmarkTicker,NavDate,NAVPrice,ClassNetAsset,ClassNetAssetRC,FundNetAssetValue,FundNetAssetValueRC"
    
    urlRep02244_perf = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02244?" \
        +"&FromDate='"+date+"'&ReportDate='"+date+"'&ISINs='"+ lstIsin \
        +"'&Periods='13W,1M,1W,2Y,5Y,YTD'&PortfolioGroupTypes=''&ShowOnlyME=''&$select=ISIN,Fund_Code,Fund_Definition,Performance_Period,BM_TWR_RC,Fund_TWR_Gross "

        
    
    df_num=GetTable(urlRep02244_perf)    
    df_name = GetTable(urlRep02361_FundInfo)   
    
    
    if (df_num.empty == False and df_name.empty ==False) :
        #return TransformTableNum(df_num)
        
        test2=TransformTableNum(df_num)
        #test1=TransformTableName(df_name)
        df_final=pd.merge(test2,df_name,how='left',on=['ISIN'])
        df_final.to_excel('dffinal.xlsx')
        global df_final_global
        df_final_global = df_final
        
        return df_final
    
    return ''

def GetTable(url):
    headers = {
      'Authorization': 'Basic c3dpc3Ncc2xyYmFtYTpDb2duaTIxJDA2'
    }  
    payload={}
    response = requests.request("GET", url, headers=headers, data=payload)

    df = pd.json_normalize(response.json()['value'])

    return df
   


#dff=pd.DataFrame(columns=('ISIN','Fund_or_Bench','13W','1M','1W','5Y','YTD','2Y'))
def TransformTableNum(df):
    import pandas as pd
    import numpy as np 
    col=[
        'ISIN',
        'fund_13W',
        'fund_1M',
        'fund_1W',
        'fund_5Y',
        'fund_YTD',
        'fund_2Y',
        'bench_13W',
        'bench_1M',
        'bench_1W',
        'bench_5Y',
        'bench_YTD',
        'bench_2Y']
           
    dff=pd.DataFrame(columns=col)


    for i in df['ISIN'].unique():
        temp = df[df['ISIN']==i][['Performance_Period','BM_TWR_RC','Fund_TWR_Gross']]
        temp=temp.T
        temp.columns = temp.iloc[0]
        temp=temp.drop(temp.index[0])
        temp['ISIN']=i
        
        list_dif=[i  for i in ['13W','YTD','1W','1M','5Y','2Y'] if i not in temp.columns.tolist()]
        for x in list_dif:
            temp[x]=np.nan
    
        row=[i,
            temp['13W']['Fund_TWR_Gross'],
            temp['1M']['Fund_TWR_Gross'],
            temp['1W']['Fund_TWR_Gross'],
            temp['5Y']['Fund_TWR_Gross'],
            temp['YTD']['Fund_TWR_Gross'],
            temp['2Y']['Fund_TWR_Gross'],
            temp['13W']['BM_TWR_RC'],
            temp['1M']['BM_TWR_RC'],
            temp['1W']['BM_TWR_RC'],
            temp['5Y']['BM_TWR_RC'],
            temp['YTD']['BM_TWR_RC'],
            temp['2Y']['BM_TWR_RC'],
            
            ]    
        dff.loc[len(dff)]=row 
        
    return dff

def calcPercent(val,valcomp):

    return ((val-valcomp)/valcomp)*100


def TransformTableName(df):
    
    for i in df['ISIN'].unique():
        dff2=pd.DataFrame()
        df_temp = df[df['ISIN']==i][['ISIN','SecurityLongName','BenchmarkOfficial_AMF']]
        #df_temp.loc[1,:]=df_temp.loc[0].values.tolist()
        df_temp.loc[1,:]=[df_temp.iloc[0,0],df_temp.iloc[0,2],df_temp.iloc[0,1]]
        df_temp['Fund_or_Bench']=['Fund_TWR_Gross','BM_TWR_RC']
        del df_temp['BenchmarkOfficial_AMF']
        df_temp.rename(columns = {'SecurityLongName':'MULTI ASSET'}, inplace = True)
        dff2=pd.concat([dff2,df_temp])
        
    return dff2


def make_dash_table(df,colList):
    """ Return a dash definition of an HTML table for a Pandas dataframe """
    rowList = []
    
    #create header row    
    html_rowheader = []
    for col in colList:
        html_rowheader.append(html.Th(col))
    rowList.append(html.Tr(html_rowheader,className ='perftableHeader'))    
    
    for index, row in df.iterrows(): 
        #Fund perf
        html_row_fund = []                   
        html_row_fund.append(html.Td([row['SecurityLongName']]))
        html_row_fund.append(html.Td([
            math.trunc(row['FundNetAssetValue']/1000000)            
            ]))
        html_row_fund.append(html.Td(''))
        html_row_fund.append(html.Td([formatPercent(row['fund_YTD'],False)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(row['fund_13W'],False)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(row['fund_1M'] ,False)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(row['fund_1W'] ,False)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(row['fund_2Y'] ,False)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(row['fund_5Y'] ,False)],className='perftableCell'))
        rowList.append(html.Tr(html_row_fund,className='perftableFund'))
        #Bench perf
        html_row_fund = []                   
        html_row_fund.append(html.Td([row['BenchmarkOfficial_AMF']]))
        html_row_fund.append(html.Td(''))
        html_row_fund.append(html.Td(''))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_YTD']	,row['bench_YTD'])	,True)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_13W']	,row['bench_13W'])	,True)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_1M'] 	,row['bench_1M'] )	,True)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_1W'] 	,row['bench_1W'] )	,True)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_2Y'] 	,row['bench_2Y'] )	,True)],className='perftableCell'))
        html_row_fund.append(html.Td([formatPercent(	calcPercent(row['fund_5Y'] 	,row['bench_5Y'] )	,True)],className='perftableCell'))
        rowList.append(html.Tr(html_row_fund,className='perftableBench'))
    
    
    return html.Table(rowList,className='perfTable')

def htmlvalueformat(val):
    if val is None :
        return html.A('')
    if val < 0 :
        return html.A(val,className='negativeValues')
    
def formatPercent(val,redIfNeg):
    if val is None or math.isnan(val) :
        return ''
    
    strVal = str(round(val,2)) +' %'
    if val<0 and redIfNeg :
        return  html.A(strVal,className='negativeValues')
    else :
        return strVal
