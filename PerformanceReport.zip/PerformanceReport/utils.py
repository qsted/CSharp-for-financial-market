from dash import html
from dash import dcc
import dash_bootstrap_components as dbc


def Header(app,username):
    return html.Div(
            [get_header(app,username),
             get_menu(username),
             ])


def get_header(app,username):
    header = html.Div(
                [
                    html.Div(
                        [html.H3("Performance report")],
                        className = 'app_title'
                    ),
                    html.Img(
                        src=app.get_asset_url("slam.png"),
                            className="logo",
                    )
                ],
                className="app__header",
                style={"padding-left": "0"},
            )
    return header


def get_menu(username):
    menu = html.Div(
        dbc.Row([
                dbc.Col(
                    dbc.Nav([
                        dbc.NavLink("Reports", href="/apps/reports",external_link=True),
                        dbc.NavLink("Configuration", href="/apps/configuration",external_link=True),
                        dbc.NavLink("", href="#"),                    
                        ],
                        pills=True,
                        fill=True
                    ),
                    width = 10),
                dbc.Col(dbc.Nav([
                    dbc.NavLink('User : '+username, 
                                disabled=True, 
                                href="#")
                    ],horizontal = 'end'))
                ],
            className = 'g-0'
            )
        )
    return menu


def make_dash_table(df):
    """ Return a dash definition of an HTML table for a Pandas dataframe """
    table = []
    for index, row in df.iterrows():
        html_row = []
        for i in range(len(row)):
            html_row.append(html.Td([row[i]]))
        table.append(html.Tr(html_row))
    return table
